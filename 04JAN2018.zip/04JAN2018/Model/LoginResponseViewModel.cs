﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Models
{
    public class LoginResponseViewModel
    {
        public int ID { get; set; }
        public string Username { get; set; }       
        public string EmailId { get; set; }
        public string IsLocked { get; set; }
         public string IPAddress { get; set; }
        public string LastLogin { get; set; }
       
        public Nullable<DateTime> CreatedDate { get; set; }
        public string UserRole { get; set; }
        public string UserRoleID { get; set; }
        public string UserRestaurant { get; set; }
        public string UserRestaurantID { get; set; }

    }
}