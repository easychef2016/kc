﻿(function (app) {
  
    app.factory('membershipService', membershipService);

    membershipService.$inject = ['apiService', 'notificationService', '$http', '$base64', '$cookies', '$rootScope'];

    function membershipService(apiService, notificationService, $http, $base64, $cookies, $rootScope) {

        var service = {
            login: login,
            register: register,
            saveCredentials: saveCredentials,
            removeCredentials: removeCredentials,
          
            isUserLoggedIn: isUserLoggedIn
        }

        function login(user, completed) {
            apiService.post('/api/account/authenticate', user,
            completed,
            loginFailed);
        }
              

        

        function register(user, completed) {
            apiService.post('/api/account/register', user,
            completed,
            registrationFailed);
        }

        function saveCredentials(user) {
            var membershipData = $base64.encode(user.Username + ':' + user.Password);

           

            $rootScope.repository = {
                loggedUser: {
                    username: user.Username,
                    createddate: user.CreatedDate,
                    userRole: user.UserRole,
                    authdata: membershipData
                }
            };

            var repositoryobj = {
                loggedUser: {
                    username: user.Username,
                    createddate: user.CreatedDate,
                    UserRole: user.UserRole,
                    authdata: membershipData
                }
            };

            $http.defaults.headers.common['Authorization'] = 'Basic ' + membershipData;
           // $cookies.put('repository', $rootScope.repository);          
            $cookies.putObject('repository', $rootScope.repository);
        }

        function removeCredentials() {
            $rootScope.repository = {};
            $cookies.remove('repository');
            $http.defaults.headers.common.Authorization = '';
        };

        function loginFailed(response) {
            notificationService.displayError(response.data);
        }

       

        function registrationFailed(response) {
            debugger;
            console.log(response);
            //notificationService.displayError('Registration failed. Try again.');
            notificationService.displayError(response.data.Message);
        }

        function isUserLoggedIn() {
            return $rootScope.repository.loggedUser != null;
        }

        return service;
    }



})(angular.module('common.core'));