﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;
namespace EasyChefDemo.Data.Configurations
{
    public class EQCategoryProductConfiguration : EntityBaseConfiguration<EQCategoryProduct>
    {
        public EQCategoryProductConfiguration()
        {
            Property(a => a.Name).IsRequired().HasMaxLength(50);
            Property(a => a.Description).IsOptional();
            Property(a => a.Sku).IsOptional();
            Property(a => a.Price).IsRequired();
            Property(a => a.Image).IsRequired();
            Property(a => a.Status).IsOptional();

            //HasMany(r => r.Suppliers).WithRequired().HasForeignKey(ra => ra.);
            //Relationships
            HasMany(r => r.SuppliersEQProducts).WithRequired().HasForeignKey(sp => sp.ProductId);
            HasMany(r => r.ProductAttributes).WithRequired().HasForeignKey(pa => pa.ProductId);
            HasMany(r => r.ProductSpecificationAttributes).WithRequired().HasForeignKey(psa => psa.ProductId);
        }
    }
}
