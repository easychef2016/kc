﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    public class EQCategoryProductSpecificationConfiguration:EntityBaseConfiguration<EQCategoryProductSpecificationAttribute>
    {
        public EQCategoryProductSpecificationConfiguration()
        {
            Property(a => a.CustomValue).IsOptional();
            Property(a => a.AllowFiltering).IsOptional();
            Property(a => a.ProductId).IsOptional();

            HasMany(a => a.Product).WithRequired().HasForeignKey(ra => ra.ID);
        }
    }
}
