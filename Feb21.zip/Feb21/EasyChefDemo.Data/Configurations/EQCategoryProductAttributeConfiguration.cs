﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;
namespace EasyChefDemo.Data.Configurations
{
    public class EQCategoryProductAttributeConfiguration:EntityBaseConfiguration<EQCategoryProductAttribute>
    {
        public EQCategoryProductAttributeConfiguration()
        {
            Property(a => a.Name).IsOptional();
            Property(a => a.Description).IsOptional();
            Property(a => a.ProductId).IsOptional();

            HasMany(a => a.Product).WithRequired().HasForeignKey(ra => ra.ID);
        }
    }
}
