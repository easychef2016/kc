﻿(function (app) {
    'use strict';

    app.controller('unitItemAddCtrl', unitItemAddCtrl);

    unitItemAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService'];

    function unitItemAddCtrl($scope, $location, $timeout, apiService, notificationService) {

        //alert("Unit Add");
        $scope.DeleteUnitItem = DeleteUnitItem;
        $scope.addUnitItemToList = addUnitItemToList;
        $scope.CreateUnitItem = CreateUnitItem;
        $scope.UnitItemList = {}

        $scope.submitted = false;
        $scope.submitting = false;

        $scope.UnitItems = [];



        function initializeUnitItems() {
            $scope.UnitItems = [
            {
                'Name': ''
            }];
        }
        
        initializeUnitItems();
        

        function DeleteUnitItem(index) {
            $scope.UnitItems.splice(index, 1);
        }

        function addUnitItemToList() {

            $scope.UnitItems.push(
            {
                'Name': '',
                'Status': ''
            });
        }

        function CreateUnitItem() {

             $scope.submitted = true;

            if ($scope.UnitItemsForm.$valid) {
                $scope.submitting = true;

                var UnitItemList = {};
                UnitItemList = angular.copy($scope.UnitItems);
                apiService.post('/api/units/add', UnitItemList,
                createUnitItemSucceded,
                createUnitItemFailed);

            }
            
        }


        function createUnitItemSucceded(response) {
            notificationService.displaySuccess('Unit Item has been submitted ');
            $scope.submitting = false;
            initializeUnitItems();

        }

        function createUnitItemFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
             $scope.submitting = false;
        }



    }

})(angular.module('easychefdemo'));