﻿(function (app) {
    'use strict';

    app.controller('EquipmentcategoriesCtrl', EquipmentcategoriesCtrl);

    EquipmentcategoriesCtrl.$inject = ['$scope', 'apiService', 'notificationService'];

    function EquipmentcategoriesCtrl($scope, apiService, notificationService) {

        // $scope.pageClass = 'page-home';
        $scope.loadingequipcategories = true;
        $scope.isReadOnly = true;

        $scope.latestequipcategories = [];
        $scope.selectedcategory = {};


        $scope.loadData = loadData;

        //below var declared for edit/update/cancel
        $scope.newCategories = [];






        function loadData() {
            apiService.get('/api/equipmentcategories/latest', null,
                equipcategoriesLoadCompleted,
                equipcategoriesLoadFailed);

        }

        function equipcategoriesLoadCompleted(result) {

            $scope.latestequipcategories = result.data;
        }

        function equipcategoriesLoadFailed(response) {

            notificationService.displayError(response.data);
        }






        loadData();
    }

})(angular.module('easychefdemo'));