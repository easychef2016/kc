﻿(function (app) {
    'use strict';

    app.controller('EquipmentcategoriesEditCtrl', EquipmentcategoriesEditCtrl);

    EquipmentcategoriesEditCtrl.$inject = ['$scope', 'apiService', 'notificationService'];

    function EquipmentcategoriesEditCtrl($scope, apiService, notificationService) {

        // $scope.pageClass = 'page-home';
        $scope.loadingcategories = true;
        $scope.isReadOnly = true;

        $scope.latestequipcategories = [];
        $scope.selectedcategory = {};


        $scope.loadData = loadData;

        //below var declared for edit/update/cancel
        $scope.newCategories = [];
        $scope.editing = false;

        $scope.getStatusColor = getStatusColor;
        $scope.getStatustext = getStatustext;

        function getStatusColor(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'green'
            else {
                return 'red';
            }
        }

        function getStatus(status) {

            if (status == 'True' || status == true)
                return 'true'
            else {
                return 'false';
            }

        }

        function getStatustext(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }



        function loadData() {
            apiService.get('/api/equipmentcategories/latest', null,
                categoriesLoadCompleted,
                categoriesLoadFailed);

        }

        function categoriesLoadCompleted(result) {
            $scope.latestequipcategories = result.data;
            $scope.loadingcategories = false;
        }

        function categoriesLoadFailed(response) {

            notificationService.displayError(response.data);
        }

        $scope.editCategory = function (category) {
            //alert(category.Status);
            $scope.editing = $scope.latestequipcategories.indexOf(category);
            $scope.newCategories[$scope.editing] = angular.copy(category);


        };

        $scope.updateCategory = function (category) {
            if ($scope.images.length > 0) {
                category.Image = $scope.images[$scope.editing].replace(/^data:image\/(png|jpeg);base64,/, "")
            }
            $scope.selectedcategory = angular.copy(category);
            apiService.post('/api/equipmentcategories/update', category,
                updateCategoryItemSucceded,
                updateCategoryItemSFailed);
        };


        $scope.cancel = function (index) {

            //if ($scope.editing !== false) {
            $scope.latestequipcategories[$scope.editing] = $scope.newCategories[index];
            $scope.editing = false;
            //}
        };


        function updateCategoryItemSucceded(response) {
            console.log(response);
            notificationService.displaySuccess($scope.selectedcategory.Name + ' has been updated');
            loadData();

        }

        function updateCategoryItemSFailed(response) {
            notificationService.displayError(response);
        }

        $scope.images = [];
        $scope.display = $scope.images[$scope.images.length - 1];
        $scope.upload = function (obj) {
            var elem = obj.target || obj.srcElement;
            for (var i = 0; i < elem.files.length; i++) {
                var file = elem.files[i];
                var reader = new FileReader();

                reader.onload = function (e) {
                    $scope.images.push(e.target.result);
                    // $scope.equipCategoryItems[i].Image = $scope.images[i];
                    //$scope.display = e.target.result;
                    $scope.$apply();
                }
                reader.readAsDataURL(file);
                //readAsDataURL
            }
        }


        loadData();
    }

})(angular.module('easychefdemo'));