﻿(function (app) {
    'use strict';

    app.controller('categoryItemEditCtrl', categoryItemEditCtrl);

    categoryItemEditCtrl.$inject = ['$scope', '$location', '$stateParams', 'apiService', 'notificationService'];

    function categoryItemEditCtrl($scope, $location, $stateParams, apiService, notificationService) {

        

        $scope.categories = [];
        
        
        function loadcategories() {
            $scope.categories = [{
                ID: 'true',
                Name: 'Active'
            }, {
                ID: 'false',
                Name: 'InActive'
            }];
        }


        $scope.submitted = false;
        $scope.submitting = false;



        $scope.loadingCategorytems = true;
        $scope.Categorytems = {};

        $scope.UpdatecategoryItemModel = UpdatecategoryItemModel;




      


       


        function loadCategoryItem() {



            $scope.loadingCategorytems = true;

            apiService.get('/api/inventoryitems/details/' + $stateParams.ItemId, null,
            categoryItemLoadCompleted,
            categoryItemLoadFailed);



        }


        function categoryItemLoadCompleted(response) {
            $scope.CategoryItem = response.data;
            $scope.loadingCategorytems = false;

            loadcategories();
            loadvendors();
            loadunits();

        }

        function categoryItemLoadFailed(response) {
            notificationService.displayError(response.data);
            $scope.submitting = false;
        }


        function UpdatecategoryItemModel() {
            //alert("update ")
            $scope.submitted = true;

            if ($scope.InventoryItemEditForm.$valid) {
                $scope.submitting = true;
                apiService.post('/api/inventoryitems/update', $scope.InventoryItem,
                updateinventoryItemSucceded,
                updateinventoryItemSFailed);
            }
        }



        function updateinventoryItemSucceded(response) {
            console.log(response);
            notificationService.displaySuccess($scope.InventoryItem.Name + ' has been updated');
            $scope.InventoryItem = response.data;
            // movieImage = null;
        }

        function updateinventoryItemSFailed(response) {
            notificationService.displayError(response);
        }



        loadcategories();








    }

})(angular.module('easychefdemo'));