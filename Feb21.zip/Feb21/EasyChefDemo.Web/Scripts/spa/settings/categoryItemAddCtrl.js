﻿(function (app) {
    'use strict';

    app.controller('categoryItemAddCtrl', categoryItemAddCtrl);

    categoryItemAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService'];

    function categoryItemAddCtrl($scope, $location, $timeout, apiService, notificationService) {


        $scope.DeleteCategoryItem = DeleteCategoryItem;
        $scope.addCategorytem = addCategorytem;
        $scope.CreateCategoryItem = CreateCategoryItem;
        $scope.CategoryItemList = {}

        $scope.submitted = false;
        $scope.submitting = false;

        $scope.CategoryItems = [];



        function initializeCategoryItems() {
            $scope.CategoryItems = [
                {
                    'Name': ''



                }];
        }





        initializeCategoryItems();




        function DeleteCategoryItem(index) {
            $scope.CategoryItems.splice(index, 1);
        }

        function addCategorytem() {

            $scope.CategoryItems.push(
                {
                    'Name': '',
                    'Status': ''

                });
        }

        function CreateCategoryItem() {

            debugger;

            $scope.submitted = true;

            if ($scope.CategoryItemsForm.$valid) {
                $scope.submitting = true;

                var CategoryItemList = {};
                CategoryItemList = angular.copy($scope.CategoryItems);

                apiService.post('/api/categories/add', CategoryItemList,
                    createCategoryItemSucceded,
                    createCategoryItemFailed);



            }



        }


        function createCategoryItemSucceded(response) {
            notificationService.displaySuccess('Category Item has been submitted ');
            $scope.submitting = false;
            initializeCategoryItems();

        }

        function createCategoryItemFailed(response) {
            notificationService.displayError(response.data);
            $scope.submitting = false;
        }



    }

})(angular.module('easychefdemo'));