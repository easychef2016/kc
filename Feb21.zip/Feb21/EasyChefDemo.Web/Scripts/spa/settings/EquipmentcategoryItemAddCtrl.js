﻿(function (app) {
    'use strict';

    app.controller('EquipmentcategoryItemAddCtrl', EquipmentcategoryItemAddCtrl);

    EquipmentcategoryItemAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService'];

    function EquipmentcategoryItemAddCtrl($scope, $location, $timeout, apiService, notificationService) {


        $scope.DeleteequipCategoryItem = DeleteequipCategoryItem;
        $scope.addequipCategorytem = addequipCategorytem;
        $scope.CreateequipCategoryItem = CreateequipCategoryItem;
        $scope.equipCategoryItemList = {}

        $scope.submitted = false;
        $scope.submitting = false;

        $scope.equipCategoryItems = [];

        $scope.CategoryItemsForm = [];

        function initializeequipCategoryItems() {
            $scope.equipCategoryItems = [
                {
                    'Name': '',
                    'Image': ''


                }];
        }





        initializeequipCategoryItems();




        function DeleteequipCategoryItem(index) {
            $scope.equipCategoryItems.splice(index, 1);
        }

        function addequipCategorytem() {

            $scope.equipCategoryItems.push(
                {
                    'Name': '',
                    'Image': '',
                    'Status': ''


                });
        }



        function CreateequipCategoryItem() {


            debugger;
            $scope.submitted = true;
            if ($scope.CategoryItemsForm.$valid) {
                $scope.submitting = true;

                var equipCategoryItemList = {};
                for (var j = 0; j < $scope.images.length; j++) {
                    $scope.equipCategoryItems[j].Image = $scope.images[j].replace(/^data:image\/(png|jpeg);base64,/, "")
                }
                equipCategoryItemList = angular.copy($scope.equipCategoryItems);

                apiService.post('/api/equipmentcategories/add', equipCategoryItemList,
                    createequipCategoryItemSucceded,
                    createequipCategoryItemFailed);



            }



        }


        function createequipCategoryItemSucceded(response) {
            notificationService.displaySuccess('Category Item has been submitted ');
            $scope.submitting = false;
            initializeequipCategoryItems();

        }

        function createequipCategoryItemFailed(response) {
            notificationService.displayError(response.data);
            $scope.submitting = false;
        }

        $scope.images = [];
        $scope.display = $scope.images[$scope.images.length - 1];
        $scope.upload = function (obj) {
            var elem = obj.target || obj.srcElement;
            for (var i = 0; i < elem.files.length; i++) {
                var file = elem.files[i];
                var reader = new FileReader();

                reader.onload = function (e) {
                    $scope.images.push(e.target.result);
                    // $scope.equipCategoryItems[i].Image = $scope.images[i];
                    //$scope.display = e.target.result;
                    $scope.$apply();
                }
                reader.readAsDataURL(file);
                //readAsDataURL
            }
        }


        //app.directive("fileread", [function () {
        //    debugger;
        //    return {

        //        scope: {
        //            fileread: "="
        //        },
        //        link: function (scope, element, attributes) {
        //            element.bind("change", function (changeEvent) {
        //                var reader = new FileReader();
        //                reader.onload = function (loadEvent) {
        //                    scope.$apply(function () {
        //                        scope.fileread = loadEvent.target.result;
        //                    });
        //                }
        //                reader.readAsDataURL(changeEvent.target.files[0]);
        //            });
        //        }
        //    }
        //}]);


    }

})(angular.module('easychefdemo'));