﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Models
{
    public class SupplierEQProductViewModel
    {
        public int ID { get; set; }
        public int SupplierId { get; set; }
        public int ProductId { get; set; }
        public virtual SupplierViewModel Supplier { get; set; }
    }
}