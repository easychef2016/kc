﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Models
{
    public class EQCategoryProductSpecificationViewModel
    {
        public int ID { get; set; }
        public int ProductId { get; set; }
        public string CustomValue { get; set; }
        public bool AllowFiltering { get; set; }
    }
}