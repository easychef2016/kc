﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using EasyChefDemo.Web.Infrastructure.Validators;
namespace EasyChefDemo.Web.Models
{
    public class EQCategoryProductViewModel
    {

        public int ID { set; get; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Sku { get; set; }

        public decimal Price { get; set; }

        public string Image { get; set; }

        public string EQCategoryId { set; get; }

        public bool Status { get; set; }

        public int SupplierId { get; set; }
        public virtual SupplierEQProductViewModel SuppliersEQProducts { get; set; }
        public virtual EQCategoryProductAttributeViewModel ProductAttributes { get; set; }

        public virtual EQCategoryProductSpecificationViewModel ProductSpecificationAttributes { get; set; }
        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}