﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class EQCategoryProductSpecificationAttribute : IEntityBase
    {
        public EQCategoryProductSpecificationAttribute()
        {

            Product = new List<EQCategoryProduct>();


        }
        public int ID { get; set; }
        public int ProductId { get; set; }
        public string CustomValue { get; set; }
        public bool AllowFiltering { get; set; }

        public virtual ICollection<EQCategoryProduct> Product { get; set; }
    }
}
