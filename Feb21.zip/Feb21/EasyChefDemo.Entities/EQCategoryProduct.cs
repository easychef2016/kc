﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class EQCategoryProduct : IEntityBase
    {
        public EQCategoryProduct()
        {
            SuppliersEQProducts = new List<SupplierEQProduct>();
            ProductAttributes = new List<EQCategoryProductAttribute>();
            ProductSpecificationAttributes = new List<EQCategoryProductSpecificationAttribute>();
        }

        public int ID { set; get; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Sku { get; set; }

        public decimal Price { get; set; }

        public string Image { get; set; }

        public string EQCategoryId { set; get; }

        public bool Status { get; set; }

        public int SupplierId { get; set; }
        public virtual ICollection<SupplierEQProduct> SuppliersEQProducts { get; set; }
        public virtual ICollection<EQCategoryProductAttribute> ProductAttributes { get; set; }

        public virtual ICollection<EQCategoryProductSpecificationAttribute> ProductSpecificationAttributes { get; set; }
        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
