﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class SupplierEQProduct : IEntityBase
    {
        public int ID { get; set; }
        public int SupplierId { get; set; }
        public int ProductId { get; set; }
        public virtual Supplier Supplier { get; set; }
    }
}
